
import ProjectVisitTracker from "./analyticsa/ProjectVisitTracker";

import {
  Routes,
  Route,
  Link,
} from "react-router-dom";

import "./App.css";

import Doctors from "./pages/Doctors";
import DoctorDetails from "./pages/DoctorDetails";
import Departments from "./pages/Departments";


/* =====================================================
   HOME PAGE
===================================================== */

function Home() {
  return (
    <div className="hospital-app">
      <ProjectVisitTracker />

      {/* =================================================
          HEADER
      ================================================= */}

      <header className="hospital-header">

        <Link
          to="/"
          className="hospital-logo"
        >

          <span className="logo-icon">
            ✚
          </span>

          <div>

            <h1>
              NOOR

            </h1>

            <span>
              HEALTH & MEDICAL CENTER
            </span>

          </div>

        </Link>


        <nav className="hospital-nav">

          <Link to="/">
            Home
          </Link>

          <a href="#about">
            About
          </a>

          <a href="#departments">
            Departments
          </a>

          <Link to="/doctors">
            Doctors
          </Link>

          <a href="#services">
            Services
          </a>

          <a href="#contact">
            Contact
          </a>

        </nav>


        <a
          href="#appointment"
          className="header-appointment"
        >
          Book Appointment
        </a>

      </header>


      {/* =================================================
          MAIN CONTENT
      ================================================= */}

      <main>


        {/* =================================================
            HERO
        ================================================= */}

        <section
          id="home"
          className="hospital-hero"
        >

          <div className="hero-content">

            <span className="hero-label">
              ✦ ADVANCED HEALTHCARE ✦
            </span>

            <h2>
              Your Health.
              <br />

              <strong>
                Our Priority.
              </strong>
            </h2>

            <p>
              Compassionate healthcare, advanced
              technology and experienced medical
              professionals — all under one roof.
            </p>


            <div className="hero-buttons">

              <a
                href="#appointment"
                className="hero-primary"
              >
                Book an Appointment →
              </a>

              <Link
                to="/doctors"
                className="hero-secondary"
              >
                Find a Doctor
              </Link>

            </div>

          </div>


          <div className="hero-medical-card">

            <div className="medical-cross">
              ✚
            </div>

            <span>
              24 / 7
            </span>

            <h3>
              Emergency
              <br />
              Care
            </h3>

            <p>
              Immediate medical attention
              whenever you need it.
            </p>

            <a href="#emergency">
              Emergency Services →
            </a>

          </div>

        </section>


        {/* =================================================
            QUICK SERVICES
        ================================================= */}

        <section className="quick-services">

          <QuickService
            icon="🚑"
            title="Emergency"
            text="24/7 Emergency Care"
          />

          <QuickService
            icon="👨‍⚕️"
            title="Find a Doctor"
            text="Qualified Specialists"
          />

          <QuickService
            icon="📅"
            title="Appointments"
            text="Book Your Visit"
          />

          <QuickService
            icon="💊"
            title="Pharmacy"
            text="Hospital Medical Store"
          />

        </section>


        {/* =================================================
            ABOUT
        ================================================= */}

        <section
          id="about"
          className="about-section"
        >

          <div className="about-content">

            <span className="section-label">
              ABOUT OUR HOSPITAL
            </span>

            <h2>
              Healthcare Built
              <br />
              Around{" "}
              <strong>
                You
              </strong>
            </h2>

            <p>
              We are committed to providing safe,
              accessible and compassionate healthcare
              through experienced doctors, skilled nurses
              and modern medical facilities.
            </p>

            <p>
              From routine consultations to advanced
              treatment and emergency care, our hospital
              brings multiple medical specialties together
              in one trusted healthcare environment.
            </p>

            <Link
              to="/doctors"
              className="learn-more"
            >
              Meet Our Doctors →
            </Link>

          </div>


          <div className="about-stats">

            <Stat
              number="25+"
              text="Medical Departments"
            />

            <Stat
              number="100+"
              text="Qualified Doctors"
            />

            <Stat
              number="250+"
              text="Nursing Staff"
            />

            <Stat
              number="24/7"
              text="Emergency Service"
            />

          </div>

        </section>


        {/* =================================================
            DEPARTMENTS
        ================================================= */}

        <section
          id="departments"
          className="departments-section"
        >

          <div className="section-heading">

            <span className="section-label">
              MEDICAL DEPARTMENTS
            </span>

            <h2>
              Expert Care for
              <br />

              <strong>
                Every Need
              </strong>
            </h2>

            <p>
              Our multidisciplinary departments provide
              specialized healthcare for patients of all ages.
            </p>

          </div>


          <div className="department-grid">

            <Department
              icon="❤️"
              title="Cardiology"
              text="Heart and cardiovascular care."
            />

            <Department
              icon="🧠"
              title="Neurology"
              text="Brain and nervous system care."
            />

            <Department
              icon="🦴"
              title="Orthopedics"
              text="Bone, joint and muscle treatment."
            />

            <Department
              icon="👶"
              title="Pediatrics"
              text="Specialized healthcare for children."
            />

            <Department
              icon="🩺"
              title="General Medicine"
              text="Comprehensive adult healthcare."
            />

            <Department
              icon="👩‍⚕️"
              title="Gynecology"
              text="Women's health and maternity care."
            />

          </div>


          <div className="section-action">

            <Link
              to="/departments"
              className="hero-primary"
            >
              Explore All Departments →
            </Link>

          </div>

        </section>


        {/* =================================================
            DOCTORS
        ================================================= */}

        <section
          id="doctors"
          className="doctors-section"
        >

          <div className="section-heading">

            <span className="section-label">
              OUR MEDICAL TEAM
            </span>

            <h2>
              Meet Our
              <br />

              <strong>
                Specialists
              </strong>
            </h2>

            <p>
              Experienced healthcare professionals
              dedicated to your wellbeing.
            </p>

          </div>


          <div className="doctor-preview-grid">

            <DoctorPreview
              icon="👩‍⚕️"
              specialty="Cardiologist"
              name="Dr. Ayesha Rahman"
              qualification="MBBS, FCPS"
            />

            <DoctorPreview
              icon="👨‍⚕️"
              specialty="Neurologist"
              name="Dr. Muhammad Ali"
              qualification="MBBS, FCPS, MRCP"
            />

            <DoctorPreview
              icon="👩‍⚕️"
              specialty="Pediatrician"
              name="Dr. Sara Ahmed"
              qualification="MBBS, MCPS, FCPS"
            />

          </div>


          <div className="section-action">

            <Link
              to="/doctors"
              className="hero-primary"
            >
              View All Doctors →
            </Link>

          </div>

        </section>


        {/* =================================================
            EMERGENCY
        ================================================= */}

        <section
          id="emergency"
          className="emergency-section"
        >

          <div className="emergency-content">

            <span className="emergency-label">
              🚨 EMERGENCY DEPARTMENT
            </span>

            <h2>
              Medical Emergency?
              <br />

              <strong>
                We're Here 24/7.
              </strong>
            </h2>

            <p>
              Our emergency department provides
              immediate medical attention with trained
              doctors, nurses and emergency support staff.
            </p>


            <div className="emergency-actions">

              <a
                href="tel:1122"
                className="emergency-call"
              >
                📞 Call Emergency
              </a>

              <a
                href="#contact"
                className="emergency-info"
              >
                Emergency Information →
              </a>

            </div>

          </div>


          <div className="emergency-card">

            <span className="emergency-big-icon">
              🚑
            </span>

            <h3>
              Emergency Services
            </h3>

            <ul>

              <li>
                24/7 Emergency Room
              </li>

              <li>
                Ambulance Service
              </li>

              <li>
                Trauma Care
              </li>

              <li>
                Critical Care
              </li>

              <li>
                Emergency Pharmacy
              </li>

            </ul>

          </div>

        </section>


        {/* =================================================
            FACILITIES
        ================================================= */}

        <section
          id="services"
          className="facilities-section"
        >

          <div className="section-heading">

            <span className="section-label">
              HOSPITAL FACILITIES
            </span>

            <h2>
              Everything You Need
              <br />

              <strong>
                Under One Roof
              </strong>
            </h2>

          </div>


          <div className="facilities-grid">

            <Facility
              icon="🏥"
              title="Modern Hospital"
              text="Advanced healthcare environment."
            />

            <Facility
              icon="🫀"
              title="ICU & Critical Care"
              text="Continuous critical patient monitoring."
            />

            <Facility
              icon="⚕️"
              title="Operation Theatres"
              text="Modern surgical facilities."
            />

            <Facility
              icon="🩸"
              title="Blood Bank"
              text="Blood and component services."
            />

            <Facility
              icon="🧪"
              title="Diagnostic Lab"
              text="Laboratory and diagnostic services."
            />

            <Facility
              icon="💊"
              title="24/7 Pharmacy"
              text="Hospital medical store."
            />

          </div>

        </section>


        {/* =================================================
            APPOINTMENT
        ================================================= */}

        <section
          id="appointment"
          className="appointment-section"
        >

          <div className="appointment-content">

            <span className="section-label">
              APPOINTMENTS
            </span>

            <h2>
              Book Your
              <br />

              <strong>
                Appointment
              </strong>
            </h2>

            <p>
              Choose your doctor and preferred
              consultation time.
            </p>

            <Link
              to="/doctors"
              className="appointment-button"
            >
              Choose a Doctor →
            </Link>

          </div>


          <div className="appointment-info">

            <AppointmentFeature
              icon="📅"
              title="Easy Booking"
              text="Simple appointment process."
            />

            <AppointmentFeature
              icon="👨‍⚕️"
              title="Expert Doctors"
              text="Qualified specialists."
            />

            <AppointmentFeature
              icon="🕐"
              title="Flexible Hours"
              text="Multiple consultation timings."
            />

          </div>

        </section>


        {/* =================================================
            CONTACT
        ================================================= */}

        <section
          id="contact"
          className="contact-section"
        >

          <div>

            <span className="section-label">
              CONTACT US
            </span>

            <h2>
              We're Here
              <br />

              <strong>
                For You.
              </strong>
            </h2>

            <p>
              Contact our hospital for appointments,
              information and medical assistance.
            </p>

          </div>


          <div className="contact-details">

            <ContactItem
              icon="📞"
              label="Emergency"
              value="1122"
            />

            <ContactItem
              icon="📍"
              label="Hospital Address"
              value="Main Hospital Road, Pakistan"
            />

            <ContactItem
              icon="🕐"
              label="Hospital Hours"
              value="Open 24 / 7"
            />

          </div>

        </section>

      </main>


      {/* =================================================
          FOOTER
      ================================================= */}

      <footer className="hospital-footer">

        <div className="footer-logo">

          <span>
            ✚
          </span>

          <div>

            <strong>
              NOOR
            </strong>

            <small>
              HEALTH & MEDICAL CENTER
            </small>

          </div>

        </div>


        <p>
          © 2026 Medicare Health & Medical Center.
          All rights reserved.
        </p>


        <div className="footer-links">

          <Link to="/">
            Home
          </Link>

          <a href="#about">
            About
          </a>

          <Link to="/doctors">
            Doctors
          </Link>

          <Link to="/departments">
            Departments
          </Link>

          <a href="#contact">
            Contact
          </a>

        </div>

      </footer>

    </div>
  );
}


/* =====================================================
   REUSABLE HOME COMPONENTS
===================================================== */

function QuickService({
  icon,
  title,
  text,
}) {
  return (
    <div className="quick-service">

      <span>
        {icon}
      </span>

      <div>

        <h3>
          {title}
        </h3>

        <p>
          {text}
        </p>

      </div>

    </div>
  );
}


function Stat({
  number,
  text,
}) {
  return (
    <div className="stat-box">

      <strong>
        {number}
      </strong>

      <span>
        {text}
      </span>

    </div>
  );
}


function Department({
  icon,
  title,
  text,
}) {
  return (
    <div className="department-box">

      <span>
        {icon}
      </span>

      <h3>
        {title}
      </h3>

      <p>
        {text}
      </p>

      <Link to="/departments">
        View Department →
      </Link>

    </div>
  );
}


function DoctorPreview({
  icon,
  specialty,
  name,
  qualification,
}) {
  return (
    <div className="doctor-preview">

      <div className="doctor-avatar">
        {icon}
      </div>

      <span>
        {specialty}
      </span>

      <h3>
        {name}
      </h3>

      <p>
        {qualification}
      </p>

      <Link to="/doctors">
        View Profile →
      </Link>

    </div>
  );
}


function Facility({
  icon,
  title,
  text,
}) {
  return (
    <div className="facility-item">

      <span>
        {icon}
      </span>

      <h3>
        {title}
      </h3>

      <p>
        {text}
      </p>

    </div>
  );
}


function AppointmentFeature({
  icon,
  title,
  text,
}) {
  return (
    <div>

      <span>
        {icon}
      </span>

      <strong>
        {title}
      </strong>

      <p>
        {text}
      </p>

    </div>
  );
}


function ContactItem({
  icon,
  label,
  value,
}) {
  return (
    <div>

      <span>
        {icon}
      </span>

      <div>

        <small>
          {label}
        </small>

        <strong>
          {value}
        </strong>

      </div>

    </div>
  );
}


/* =====================================================
   APPLICATION ROUTES
===================================================== */

function App() {
  return (
    <Routes>

      <Route
        path="/"
        element={<Home />}
      />

      <Route
        path="/doctors"
        element={<Doctors />}
      />

      <Route
        path="/doctors/:id"
        element={<DoctorDetails />}
      />

      <Route
        path="/departments"
        element={<Departments />}
      />

    </Routes>
  );
}


export default App;