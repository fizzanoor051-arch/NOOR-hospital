import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import doctorsData from "../data/doctorsData";

function Doctors() {
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("All");

  const departments = [
    "All",
    ...new Set(
      doctorsData.map((doctor) => doctor.department)
    ),
  ];

  const filteredDoctors = useMemo(() => {
    return doctorsData.filter((doctor) => {
      const searchText = search.toLowerCase();

      const matchesSearch =
        doctor.name.toLowerCase().includes(searchText) ||
        doctor.specialty.toLowerCase().includes(searchText) ||
        doctor.department.toLowerCase().includes(searchText);

      const matchesDepartment =
        department === "All" ||
        doctor.department === department;

      return matchesSearch && matchesDepartment;
    });
  }, [search, department]);

  return (
    <main className="doctors-page">

      {/* HEADER */}

      <section className="page-hero">

        <span className="section-label">
          OUR MEDICAL TEAM
        </span>

        <h1>
          Meet Our
          <br />
          <strong>Specialists</strong>
        </h1>

        <p>
          Find experienced doctors and healthcare
          professionals dedicated to your wellbeing.
        </p>

      </section>


      {/* SEARCH */}

      <section className="doctors-controls">

        <input
          type="search"
          placeholder="Search doctor..."
          value={search}
          onChange={(event) =>
            setSearch(event.target.value)
          }
        />

        <select
          value={department}
          onChange={(event) =>
            setDepartment(event.target.value)
          }
        >
          {departments.map((item) => (
            <option
              key={item}
              value={item}
            >
              {item}
            </option>
          ))}
        </select>

      </section>


      {/* DOCTORS */}

      <section className="doctors-list">

        {filteredDoctors.length > 0 ? (
          filteredDoctors.map((doctor) => (
            <article
              className="doctor-card"
              key={doctor.id}
            >

              <div className="doctor-avatar">
                {doctor.icon}
              </div>

              <span>
                {doctor.specialty}
              </span>

              <h2>
                {doctor.name}
              </h2>

              <p>
                {doctor.qualification}
              </p>

              <small>
                {doctor.experience}
              </small>

              <Link
                to={`/doctors/${doctor.id}`}
                className="doctor-profile-link"
              >
                View Profile →
              </Link>

            </article>
          ))
        ) : (
          <div className="no-results">
            <h2>
              No Doctors Found
            </h2>

            <p>
              Try another name or department.
            </p>
          </div>
        )}

      </section>

    </main>
  );
}

export default Doctors;