import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import departmentsData from "../data/departmentsData";

function Departments() {
  const [search, setSearch] = useState("");

  const filteredDepartments = useMemo(() => {
    const value = search.toLowerCase();

    return departmentsData.filter((department) => {
      return (
        department.name
          .toLowerCase()
          .includes(value) ||
        department.shortName
          .toLowerCase()
          .includes(value)
      );
    });
  }, [search]);

  return (
    <main className="departments-page">

      {/* PAGE HERO */}

      <section className="page-hero">

        <span className="section-label">
          MEDICAL DEPARTMENTS
        </span>

        <h1>
          Expert Care for
          <br />
          <strong>Every Need</strong>
        </h1>

        <p>
          Explore our medical departments and
          specialized healthcare services.
        </p>

      </section>


      {/* SEARCH */}

      <section className="department-search">

        <input
          type="search"
          placeholder="Search department..."
          value={search}
          onChange={(event) =>
            setSearch(event.target.value)
          }
        />

      </section>


      {/* DEPARTMENTS */}

      <section className="departments-list">

        {filteredDepartments.length > 0 ? (
          filteredDepartments.map((department) => (
            <article
              className="department-card"
              key={department.id}
            >

              <div className="department-icon">
                {department.icon}
              </div>

              <span>
                {department.shortName}
              </span>

              <h2>
                {department.name}
              </h2>

              <p>
                {department.description}
              </p>

              <div className="department-services">

                {department.services
                  ?.slice(0, 3)
                  .map((service) => (
                    <small
                      key={service}
                    >
                      ✓ {service}
                    </small>
                  ))}

              </div>

              <Link
                to="/doctors"
                className="department-link"
              >
                Find Specialists →
              </Link>

            </article>
          ))
        ) : (
          <div className="no-results">

            <h2>
              No Department Found
            </h2>

            <p>
              Try searching for another department.
            </p>

          </div>
        )}

      </section>

    </main>
  );
}

export default Departments;